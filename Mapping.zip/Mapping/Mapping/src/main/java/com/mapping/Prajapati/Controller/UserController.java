package com.mapping.Prajapati.Controller;

import java.util.List;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import com.mapping.Prajapati.DTO.UserDTO;
import com.mapping.Prajapati.Service.UserService;
import com.mapping.Prajapati.Security.Jwt.JwtUtil;
import com.mapping.Prajapati.Security.CustomUserDetailsService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api-user")
public class UserController {

    private final UserService userService;
    private final AuthenticationManager authenticationManager;
    private final CustomUserDetailsService userDetailsService;
    private final JwtUtil jwtUtil;

    // ✅ JWT Login Endpoint
    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(username, password)
        );
        final UserDetails user = userDetailsService.loadUserByUsername(username);
        return jwtUtil.generateToken(user.getUsername()); // ✅ fixed
    }

    @GetMapping("/Alluser")
    public List<UserDTO> getAllUser() {
        return userService.getAllUser();
    }

    @GetMapping("/{id}")
    public UserDTO getUserById(@PathVariable Long id) {
        return userService.getById(id);
    }

    @PostMapping("/New-user")
    public UserDTO createUser(@RequestBody UserDTO dto) {
        return userService.createUser(dto);
    }

    @PutMapping("/{userId}/link-student/{studentId}")
    public UserDTO linkStudentToUser(@PathVariable Long userId, @PathVariable Long studentId) {
        return userService.linkStudent(userId, studentId);
    }

    @GetMapping("/public")
    public String publicEndpoint() {
        return "This is a public endpoint. No JWT needed.";
    }
}
