package com.mapping.Prajapati.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mapping.Prajapati.Entity.Laptop;

public interface LaptopRepository extends JpaRepository<Laptop,Long>{

    
}
